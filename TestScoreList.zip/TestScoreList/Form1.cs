﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestScoreList
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }

        int [] TestScores = new int[8];
        int ScoreCount = 0;
        Double ScoreTotal;
        Double ScoreAverage;

        private void button1_Click(object sender, EventArgs e)
        {
            
            int TestScore;
            if (int.TryParse(TestScoreInput.Text, out TestScore))
            {
                Results.Text = "";
                ErrorMessage.Text = "";
                if (ScoreCount <= 7)
                {
                    ScoreTotal += TestScore;
                    ScoreAverage = Math.Round(ScoreTotal / (ScoreCount+1),2);
                    TestScores[ScoreCount] = TestScore;
                    ScoreCount++;

                    ScoreAvgLbl.Text = $"Running Average: {ScoreAverage.ToString()}";
                    TestScoreInput.Text = "";
                    TestScoreInput.Focus();
                    for (int i = 0; i < 8; i++)
                    {
                        Results.Text += $"Test Score #{(i+1).ToString()} Grade: {TestScores[i].ToString()}     +/- Of Average:  {(TestScores[i]-ScoreAverage).ToString("F2")} \n";
                    }
                    if (ScoreCount == 8)
                    {
                        button1.Enabled = false;
                    }
                }                
            }
            else 
            { 
                ErrorMessage.Text = "Bad";
            }
        }

        private void ScoreAvgLbl_Click(object sender, EventArgs e)
        {

        }
    }
}
